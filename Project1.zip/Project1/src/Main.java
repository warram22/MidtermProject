import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;



public class Main {
	public static void main( String[] args){
		
	}
}
