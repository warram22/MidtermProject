import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
public class MyImage {
		public static void main(String args[])throws IOException{
			int width = 1024;
			int height = 768;
			BufferedImage image = null;
			File f = null;
			BufferedImage image1 = null;
			//read image
			try{
				f = new File("C:\\Users\\Public\\Pictures\\Sample Pictures\\Koala.jpg");
				image1 = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
				image1 = ImageIO.read(f);
				System.out.println("Reading Complete");
				
			}
			catch(IOException e){
				System.out.println("Error:"+e);
				
			}
			//write image
			try{
				f = new File("C:\\Users\\Public\\Pictures\\Sample Pictures\\Koala.jpg");
				ImageIO.write(image1, "jpg", f);
				System.out.println("Writing Complete");
			}
			catch(IOException e){
				System.out.println("ERROR:" +e);
			}
		}
	}
